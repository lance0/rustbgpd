# Criterion Compare Summary

- Run: `20260726T165606Z-643900e76d11-vs-ed3b7a72fde7-rustbgpd-wire-codec`
- Base: `643900e76d11` (`643900e76d1101a50974dcdac1c1e2b36c7991cc`)
- Head: `ed3b7a72fde7` (`ed3b7a72fde7d69eff51d334e7feb65d698bae60`)
- Attempts: 6 (alternating order: odd = base-first, even = head-first)
- Verdict mode: fail on confident regression
- Regression threshold: mean delta >= 3% with min..max and the last-run 95% CI both entirely above zero, stddev < 10%, with >= 6 completed attempts (delta-only rows whose 95% CI straddles zero stay advisory)
- Metadata: `<RUN_ROOT>/02-attr-target/20260726T165606Z-643900e76d11-vs-ed3b7a72fde7-rustbgpd-wire-codec/metadata.txt`
- Criterion artifacts: `<RUN_ROOT>/02-attr-target/20260726T165606Z-643900e76d11-vs-ed3b7a72fde7-rustbgpd-wire-codec/criterion`

| Benchmark | attempts | base median (mean) | head median (mean) | mean delta | stddev | min..max | last-run 95% CI | verdict |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| `attr_encode/rich/11` | 6/6 | 492.1 ns | 352.6 ns | -28.34% | 0.88% | -29.39%..-27.01% | -29.94%..-28.71% | improvement |

## Verdict

No confident regressions by the configured verdict rule.
