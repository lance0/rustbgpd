# Criterion Compare Summary

- Run: `20260726T170433Z-ed3b7a72fde7-vs-f95d89406921-rustbgpd-wire-codec`
- Base: `ed3b7a72fde7` (`ed3b7a72fde7d69eff51d334e7feb65d698bae60`)
- Head: `f95d89406921` (`f95d894069216662c33e9c109e2891d12fb8350f`)
- Attempts: 6 (alternating order: odd = base-first, even = head-first)
- Verdict mode: fail on confident regression
- Regression threshold: mean delta >= 3% with min..max and the last-run 95% CI both entirely above zero, stddev < 10%, with >= 6 completed attempts (delta-only rows whose 95% CI straddles zero stay advisory)
- Metadata: `<RUN_ROOT>/04-validate-target/20260726T170433Z-ed3b7a72fde7-vs-f95d89406921-rustbgpd-wire-codec/metadata.txt`
- Criterion artifacts: `<RUN_ROOT>/04-validate-target/20260726T170433Z-ed3b7a72fde7-vs-f95d89406921-rustbgpd-wire-codec/criterion`

| Benchmark | attempts | base median (mean) | head median (mean) | mean delta | stddev | min..max | last-run 95% CI | verdict |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| `validate_update` | 6/6 | 156.2 ns | 14.7 ns | -90.57% | 0.58% | -90.87%..-89.42% | -90.85%..-90.82% | improvement |

## Verdict

No confident regressions by the configured verdict rule.
