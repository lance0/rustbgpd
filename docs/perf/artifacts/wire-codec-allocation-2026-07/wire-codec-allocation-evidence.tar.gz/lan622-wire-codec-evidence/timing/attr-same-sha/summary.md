# Criterion Compare Summary

- Run: `20260726T165206Z-643900e76d11-vs-643900e76d11-rustbgpd-wire-codec`
- Base: `643900e76d11` (`643900e76d1101a50974dcdac1c1e2b36c7991cc`)
- Head: `643900e76d11` (`643900e76d1101a50974dcdac1c1e2b36c7991cc`)
- Attempts: 6 (alternating order: odd = base-first, even = head-first)
- Verdict mode: fail on confident regression
- Regression threshold: mean delta >= 3% with min..max and the last-run 95% CI both entirely above zero, stddev < 10%, with >= 6 completed attempts (delta-only rows whose 95% CI straddles zero stay advisory)
- Metadata: `<RUN_ROOT>/01-attr-same-sha/20260726T165206Z-643900e76d11-vs-643900e76d11-rustbgpd-wire-codec/metadata.txt`
- Criterion artifacts: `<RUN_ROOT>/01-attr-same-sha/20260726T165206Z-643900e76d11-vs-643900e76d11-rustbgpd-wire-codec/criterion`

| Benchmark | attempts | base median (mean) | head median (mean) | mean delta | stddev | min..max | last-run 95% CI | verdict |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| `attr_encode/rich/11` | 6/6 | 484.9 ns | 486.7 ns | +0.39% | 2.28% | -3.54%..+2.73% | -0.91%..-0.21% | noise |

## Verdict

No confident regressions by the configured verdict rule.
