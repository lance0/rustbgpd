# Criterion Compare Summary

- Run: `20260726T170018Z-ed3b7a72fde7-vs-ed3b7a72fde7-rustbgpd-wire-codec`
- Base: `ed3b7a72fde7` (`ed3b7a72fde7d69eff51d334e7feb65d698bae60`)
- Head: `ed3b7a72fde7` (`ed3b7a72fde7d69eff51d334e7feb65d698bae60`)
- Attempts: 6 (alternating order: odd = base-first, even = head-first)
- Verdict mode: fail on confident regression
- Regression threshold: mean delta >= 3% with min..max and the last-run 95% CI both entirely above zero, stddev < 10%, with >= 6 completed attempts (delta-only rows whose 95% CI straddles zero stay advisory)
- Metadata: `<RUN_ROOT>/03-validate-same-sha/20260726T170018Z-ed3b7a72fde7-vs-ed3b7a72fde7-rustbgpd-wire-codec/metadata.txt`
- Criterion artifacts: `<RUN_ROOT>/03-validate-same-sha/20260726T170018Z-ed3b7a72fde7-vs-ed3b7a72fde7-rustbgpd-wire-codec/criterion`

| Benchmark | attempts | base median (mean) | head median (mean) | mean delta | stddev | min..max | last-run 95% CI | verdict |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| `validate_update` | 6/6 | 156.3 ns | 156.2 ns | -0.06% | 0.35% | -0.74%..+0.30% | -0.10%..+0.16% | noise |

## Verdict

No confident regressions by the configured verdict rule.
