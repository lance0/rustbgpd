#!/usr/bin/env python3
"""Measure existing EVPN load binaries against one isolated loopback reflector."""
import argparse
from datetime import datetime
import json
import os
import re
from pathlib import Path
import subprocess
import time
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('--receivers', type=int, required=True)
parser.add_argument('--routes', type=int, default=5000, help='routes per originator')
parser.add_argument('--churn-seconds', type=int, default=10)
parser.add_argument('--churn-delay-seconds', type=int, default=10)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert 1 <= args.receivers <= 480 and args.routes >= 40 and args.churn_seconds >= 0
args.out.mkdir(parents=True, exist_ok=False)
root = args.out.resolve()
state = root / 'state'
state.mkdir()
peers = [f'127.77.{i // 250}.{i % 250 + 1}' for i in range(args.receivers + 2)]
config = f'''[global]
asn = 65000
router_id = "10.77.0.254"
cluster_id = "10.77.0.254"
listen_addresses = ["127.77.255.254"]
listen_port = 1179
runtime_state_dir = "{state}"
[global.telemetry]
prometheus_addr = "127.77.255.254:9179"
log_format = "json"
'''
for peer in peers:
    config += f'''\n[[neighbors]]
address = "{peer}"
remote_asn = 65000
families = ["l2vpn_evpn"]
route_reflector_client = true
hold_time = 180
'''
(root / 'config.toml').write_text(config)
processes = []
handles = []

def start(name, command, threads=1):
    out = open(root / f'{name}.json', 'w')
    log = open(root / f'{name}.log', 'w')
    handles.extend([out, log])
    proc = subprocess.Popen(command, stdout=out, stderr=log,
        env=os.environ | {'TOKIO_WORKER_THREADS': str(threads), 'RUST_LOG': 'info'})
    processes.append(proc)
    return proc

try:
    monitors = []
    for i, peer in enumerate(peers[2:]):
        monitors.append(start(f'monitor-{i:03}', ['/bin/evpn-monitor', '--listen', f'{peer}:179',
            '--router-id', f'10.77.{i // 250}.{i % 250 + 1}', '--expect', str(2 * args.routes),
            '--stable-sec', '1', '--timeout-sec', '180', '--observe-sec', str(args.churn_delay_seconds + args.churn_seconds + 10)]))
    for i, peer in enumerate(peers[:2]):
        start(f'tester-{i}', ['/bin/evpn-tester', '--listen', f'{peer}:179',
            '--router-id', f'10.78.0.{i + 1}', '--count', str(args.routes), '--rate', '0',
            '--batch', '40', '--churn-duration-sec', str(args.churn_seconds),
            '--churn-rate', '1000', '--churn-delay-sec', str(args.churn_delay_seconds), '--linger-sec', '240'])
    time.sleep(1)
    assert all(p.poll() is None for p in processes), 'peer failed before reflector start'
    daemon = start('daemon', ['/bin/rustbgpd', str(root / 'config.toml')], threads=8)
    started = time.monotonic()
    samples = []
    while any(p.poll() is None for p in monitors):
        if daemon.poll() is not None:
            raise RuntimeError('reflector exited; inspect daemon logs')
        assert time.monotonic() - started < 210, 'overall deadline exceeded'
        stat = Path(f'/proc/{daemon.pid}/stat').read_text().split()
        samples.append({'elapsed_sec': time.monotonic() - started,
            'cpu_sec': (int(stat[13]) + int(stat[14])) / os.sysconf('SC_CLK_TCK'),
            'rss_bytes': int(stat[23]) * os.sysconf('SC_PAGE_SIZE')})
        time.sleep(0.2)
    reports = [json.loads((root / f'monitor-{i:03}.json').read_text()) for i in range(args.receivers)]
    expected = 2 * args.routes
    def event_time(name, event):
        line = next(line for line in (root / f'{name}.log').read_text().splitlines() if event in line)
        stamp = re.search(r'\d{4}-\d{2}-\d{2}T[0-9:.]+Z', line).group()
        return datetime.fromisoformat(stamp.replace('Z', '+00:00')).timestamp()
    full_table_times = [event_time(f'monitor-{i:03}', 'session established, observing')
        + report['initial_convergence_sec'] for i, report in enumerate(reports)]
    before_churn = args.churn_seconds == 0 or max(full_table_times) < min(
        event_time(f'tester-{i}', 'starting churn phase') for i in range(2))
    valid = before_churn and all(p.returncode == 0 for p in monitors) and all(
        r['converged'] and not r['timed_out'] and r['final_count'] == expected
        and r['stats']['parse_errors'] == 0
        and (args.churn_seconds == 0 or r['total_withdrawals'] >= 1000 * args.churn_seconds)
        for r in reports)
    neighbors = subprocess.run(['/bin/rbgp', '-s', f'unix://{state}/grpc.sock', '--json', 'neighbor'],
        capture_output=True, text=True, timeout=10)
    (root / 'neighbors.json').write_text(neighbors.stdout)
    # Monitors deliberately exit after their observation window. Originators must remain live.
    neighbor_rows = json.loads(neighbors.stdout)
    valid &= all(any(p['address'] == peer and p['state'] == 'Established'
        for p in neighbor_rows) for peer in peers[:2])
    routes = subprocess.run(['/bin/rbgp', '-s', f'unix://{state}/grpc.sock', '--json', 'evpn'],
        capture_output=True, text=True, timeout=30)
    (root / 'selected.json').write_text(routes.stdout)
    selected_count = len(json.loads(routes.stdout))
    valid &= routes.returncode == 0 and selected_count == expected
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open('http://127.77.255.254:9179/metrics', timeout=10) as response:
            (root / 'metrics.txt').write_bytes(response.read())
    finally:
        (root / 'samples.json').write_text(json.dumps(samples))
    summary = {'receivers': args.receivers, 'originators': 2, 'routes_per_originator': args.routes,
        'churn_seconds': args.churn_seconds, 'all_receivers_full_before_churn': before_churn,
        'churn_delay_seconds': args.churn_delay_seconds, 'correct': bool(valid), 'selected_count': selected_count,
        'initial_convergence_min_sec': min(r['initial_convergence_sec'] for r in reports),
        'initial_convergence_max_sec': max(r['initial_convergence_sec'] for r in reports),
        'withdrawals_min': min(r['total_withdrawals'] for r in reports),
        'cpu_sec': samples[-1]['cpu_sec'], 'elapsed_sec': samples[-1]['elapsed_sec'],
        'peak_rss_bytes': max(s['rss_bytes'] for s in samples)}
    (root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
    assert valid, 'receiver correctness failed'
finally:
    for proc in reversed(processes):
        if proc.poll() is None:
            proc.terminate()
    for proc in processes:
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    for handle in handles:
        handle.close()
