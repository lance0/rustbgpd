import json,socket,struct,subprocess

def run(*args):
 p=subprocess.run(args,text=True,capture_output=True,check=True); print(json.dumps({'cmd':args,'stdout':p.stdout}),flush=True); return p.stdout
for cmd in [('ip','link','add','br100','type','bridge'),('ip','link','add','es0','type','dummy'),('ip','link','add','other0','type','dummy')]: run(*cmd)
for name in ['es0','other0']: run('ip','link','set',name,'master','br100')
for name in ['br100','es0','other0']:run('ip','link','set',name,'up')
s=socket.socket(socket.AF_NETLINK,socket.SOCK_RAW,socket.NETLINK_ROUTE); s.bind((0,0));seq=0
mac=bytes.fromhex('02aabbccdd10');ifindex=socket.if_nametoindex('es0')
def attr(kind,data):
 raw=struct.pack('HH',len(data)+4,kind)+data; return raw+b'\0'*((-len(raw))%4)
def request(kind,flags,state,ndflags,extra=b'',expected_errno=0):
 global seq
 seq+=1;payload=struct.pack('BBHiHBB',socket.AF_BRIDGE,0,0,ifindex,state,ndflags,0)+attr(2,mac)+extra
 msg=struct.pack('IHHII',len(payload)+16,kind,flags,seq,0)+payload
 print(json.dumps({'raw_request':msg.hex(),'nlmsg_type':kind,'nlmsg_flags':flags,'ndm_state':state,'ndm_flags':ndflags}),flush=True);s.send(msg)
 while True:
  reply=s.recv(65536);ln,ty,fl,sq,pid=struct.unpack_from('IHHII',reply)
  if ty==2:
   errno=struct.unpack_from('i',reply,16)[0];print(json.dumps({'errno':errno}),flush=True);assert errno==expected_errno;return errno

def raw_rows():
 global seq
 seq+=1
 payload=struct.pack('BBHiHBB',socket.AF_BRIDGE,0,0,0,0,0,0)
 s.send(struct.pack('IHHII',len(payload)+16,30,0x301,seq,0)+payload)
 out=[]
 while True:
  data=s.recv(65536);offset=0
  while offset<len(data):
   ln,ty,fl,sq,pid=struct.unpack_from('IHHII',data,offset)
   body=data[offset+16:offset+ln];offset+=(ln+3)&~3
   if ty==3:
    print(json.dumps({'raw_fdb_rows':out}),flush=True);return out
   if ty!=28:continue
   family,p1,p2,port,state,flags,kind=struct.unpack_from('BBHiHBB',body)
   attrs={};a=12
   while a<len(body):
    al,at=struct.unpack_from('HH',body,a);attrs[at&0x3fff]=body[a+4:a+al].hex();a+=(al+3)&~3
   if attrs.get(2)==mac.hex():out.append({'ifindex':port,'state':state,'flags':flags,'attrs':attrs})

def rows():return json.loads(run('bridge','-d','-j','fdb','show','br','br100'))
def target():return [r for r in rows() if r.get('mac')=='02:aa:bb:cc:dd:10']
for state in ['dynamic','static']:
 print(json.dumps({'phase':'ordinary-exclusive-control','foreign_state':state}),flush=True)
 run('bridge','fdb','add','02:aa:bb:cc:dd:10','dev','other0','master',state)
 before=target();assert before and all(r['ifname']=='other0' and 'extern_learn' not in r.get('flags',[]) for r in before)
 request(28,0x605,0x40,0x04,attr(12,b'\xba'),expected_errno=-17)
 assert target()==before,'ordinary EXCL must preserve foreign row'
 print(json.dumps({'phase':'exact-candidate-flags','foreign_state':state}),flush=True)
 request(28,0x605,0x40,0x14,attr(12,b'\xba'))
 after=target();assert after and all(r['ifname']=='es0' and 'extern_learn' in r.get('flags',[]) for r in after)
 run('bridge','fdb','del','02:aa:bb:cc:dd:10','dev','es0','master')

print(json.dumps({'phase':'controlled-check-write-insertion'}),flush=True)
assert raw_rows()==[],'candidate final ownership check sees vacant slot'
run('bridge','fdb','add','02:aa:bb:cc:dd:10','dev','other0','master','dynamic')
assert all(r['ifname']=='other0' and 'extern_learn' not in r.get('flags',[]) for r in target())
request(28,0x605,0x40,0x14,attr(12,b'\xba'))
assert all(r['ifname']=='es0' and 'extern_learn' in r.get('flags',[]) for r in target()),'controlled late insertion demonstrates remaining kernel race'

print(json.dumps({'phase':'foreign-takeover-before-final-delete-dump'}),flush=True)
run('bridge','fdb','del','02:aa:bb:cc:dd:10','dev','es0','master')
run('bridge','fdb','add','02:aa:bb:cc:dd:10','dev','es0','master','dynamic')
foreign=raw_rows();assert foreign and all(not (r['flags']&16) for r in foreign)
# The candidate's final-dump marker check sees this takeover and sends no DEL.
print(json.dumps({'guarded_delete':'skipped','reason':'final dump lacks ownership marker'}),flush=True)
assert all('extern_learn' not in r.get('flags',[]) for r in target())
print('PASS: ordinary EXCL EEXIST preserves both foreign states; exact candidate bypasses EXCL; controlled late insertion reproduced; pre-finaldump takeover skips delete',flush=True)
