import json,socket,subprocess

def run(*args):
 p=subprocess.run(args,text=True,capture_output=True,check=True); print(json.dumps({'cmd':args,'stdout':p.stdout}),flush=True); return p.stdout
run('ip','link','add','br100','type','bridge')
run('ip','link','add','es0','type','veth','peer','name','ce0')
run('ip','link','set','es0','master','br100')
for dev in ['br100','es0','ce0']:
 run('ip','link','set',dev,'addrgenmode','none')
 run('ip','link','set',dev,'up')
mac='02:aa:bb:cc:dd:10'
run('bridge','fdb','add',mac,'dev','es0','master','static','extern_learn')
def row():
 rows=json.loads(run('bridge','-d','-j','fdb','show','br','br100'))
 return [r for r in rows if r.get('mac')==mac]
before=row();assert before and all('extern_learn' in r.get('flags',[]) for r in before)
dest=bytes.fromhex(open('/sys/class/net/br100/address').read().strip().replace(':',''))
frame=dest+bytes.fromhex(mac.replace(':',''))+b'\x88\xb5'+b'peer-sync-local-source-probe'.ljust(46,b'\0')
rx=socket.socket(socket.AF_PACKET,socket.SOCK_RAW,socket.htons(0x88b5));rx.bind(('br100',0));rx.settimeout(3)
tx=socket.socket(socket.AF_PACKET,socket.SOCK_RAW);tx.bind(('ce0',0));assert tx.send(frame)==len(frame)
received=rx.recv(4096);assert received==frame
print(json.dumps({'bridge_received_from_ce':received.hex()}),flush=True)
after=row();assert after and all('extern_learn' in r.get('flags',[]) for r in after)
print('PASS: actual source frame traversed es0 into br100; same-port peer row kept extern_learn',flush=True)
