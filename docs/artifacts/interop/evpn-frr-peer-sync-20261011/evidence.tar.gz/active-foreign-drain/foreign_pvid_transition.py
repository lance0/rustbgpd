"""Bounded live-daemon peer-to-remote drain conflict proof; owned containers only."""
import json
from pathlib import Path
import sys
import time
sys.path.insert(0,'/tree/tests/interop/scripts')
import evpn_frr_peer_sync as p

p.setup()
p.wait(lambda: len(p.cli('b','neighbor'))==2 and all(r['state']=='Established' for r in p.cli('b','neighbor')), 'EVPN peers established')
p.wait(lambda: 'DF status: df ' in p.frr('a','show evpn es detail'), 'FRR DF settled')
p.wait(lambda: 'Number of ports: 2' in p.ns('ce','cat','/proc/net/bonding/bond0'), 'LACP ready')
a_mac=json.loads(p.ns('a','ip','-j','link','show','br100'))[0]['address']
p.send('ce','cea',[1],destination=a_mac,source=p.MAC)
def rows():
    return [r for r in json.loads(p.ns('b','bridge','-j','fdb','show')) if r.get('mac')==p.MAC]
def ready():
    try:p.verify_peer_rows(rows());return True
    except AssertionError:return False
p.wait(ready,'owned peer-sync kernel pair')
p.snapshot('before-foreign')
# Change only VLAN 1; leave the owned untagged row in place.
p.ns('b','bridge','fdb','del',p.MAC,'dev','es0','master','vlan','1')
p.ns('b','bridge','fdb','add',p.MAC,'dev','es0','master','static','vlan','1')
def preserved(current):
    foreign=[r for r in current if r.get('vlan')==1]
    assert len(foreign)==1 and foreign[0]['ifname']=='es0' and foreign[0].get('master')=='br100'
    assert foreign[0].get('flags',[])==[] and foreign[0].get('state')=='static'
    assert not any(r.get('dst') or r.get('nhid') or r.get('ifname')=='vx100' for r in current)
preserved(rows())
p.snapshot('before-drain')
start_offset=(p.OUT/'b-daemon.log').stat().st_size
response=p.cli('b','evpn','es','drain',p.ESI)
(p.OUT/'drain-response.json').write_text(json.dumps(response,indent=2)+'\n')
assert response['drained']
end=time.monotonic()+30
samples=[]
while time.monotonic()<end:
    current=rows();preserved(current)
    samples.append({'sample':len(samples),'fdb':current})
    with (p.OUT/'b-daemon.log').open() as log:
        log.seek(start_offset);raw=log.read()
    events=[]
    for line in raw.splitlines():
        try:events.append(json.loads(line))
        except json.JSONDecodeError:pass
    conflicts=[e for e in events if e.get('fields',{}).get('message')=='dataplane op failed; will retry' and 'RemovePeerSyncFdb' in str(e.get('fields',{}).get('op',''))]
    deferred=[e for e in events if e.get('fields',{}).get('message')=='deferred (backoff not elapsed)' and 'AddRemoteFdb' in str(e.get('fields',{}).get('op',''))]
    if len(conflicts)>=3 and deferred:
        break
    time.sleep(.1)
else:
    raise AssertionError(f'need initial conflict plus two actor retries and remote-add deferral; got {len(conflicts)} conflicts/{len(deferred)} deferrals')
(p.OUT/'transition-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
(p.OUT/'transition-events.json').write_text(json.dumps({'conflicts':conflicts,'remote_add_deferred':deferred},indent=2)+'\n')
p.snapshot('after-drain')
result={'foreign_pvid_preserved':True,'overlay_row_present':False,'remove_conflicts':len(conflicts),'remote_add_deferrals':len(deferred),'fdb_samples':len(samples),'source_commit':'7c694dbf38cef1ed19e463a1c74dbf8257cae9ff'}
(p.OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
