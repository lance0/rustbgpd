#!/usr/bin/env python3
"""Run unchanged M67 against explicitly identified, read-only mounted executables.

The cached image supplies only OS/tools. Candidate provenance is checked against
all five mounted executable pairs, independently of the dev-image source guard.
No Cargo build, shared image retag, traffic injection, or oracle relaxation.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
import uuid
import yaml

TREE=Path('<repo>')
LAB='m67-evpn-link-drain-failover'
BASE_IMAGE='sha256:e75e841c5dccc124b1cf924a9ba48c16c06a5ed4a47c671a8517d819f6acbccc'
NODES=['vtep','pe1','pe2','ce','hr']
NAMES={n:f'clab-{LAB}-{n}' for n in NODES}

def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()

def call(args, check=True, timeout=30, **kwargs):
    result=subprocess.run(args, capture_output=True, text=True, timeout=timeout, **kwargs)
    if check and result.returncode:
        raise RuntimeError(f'{args}: {result.stderr}')
    return result

def observed(args):
    try:
        result=call(args, check=False, timeout=10)
        value=dict(exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
        if result.returncode==0:
            try:
                value['json']=json.loads(result.stdout)
            except ValueError:
                pass
        return value
    except subprocess.TimeoutExpired:
        return dict(timeout_seconds=10)

def snapshot():
    result=dict(wall_time=time.time(), monotonic=time.monotonic(), nodes={})
    for node in ['vtep','pe1','pe2']:
        prefix=['docker','exec',NAMES[node]]
        state={
            'fdb':observed(prefix+['bridge','-d','-j','fdb','show']),
            'ports':observed(prefix+['bridge','-d','-j','link','show']),
            'nexthops':observed(prefix+['ip','-j','nexthop','show']),
            'bridge_config':observed(prefix+['ip','-d','-j','link','show','br100']),
        }
        token='/run/rustbgpd/grpc-test-only-operator.token' if node=='vtep' else '/etc/rustbgpd/grpc-operator.token'
        cli=prefix+['rbgp','--addr','http://127.0.0.1:50051','--token-file',token,'-j']
        state['routes']=observed(cli+['evpn'])
        if node!='vtep':
            state['segments']=observed(cli+['evpn','es','list'])
        result['nodes'][node]=state
    return result

def observe(out, stop):
    with (out/'state-samples.jsonl').open('w') as stream:
        while not stop.is_set():
            stream.write(json.dumps(snapshot())+'\n')
            stream.flush()
            stop.wait(1)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True, help='immutable daemon, CLI, provenance.json directory')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--carrier-image', default=BASE_IMAGE, help='OS/tooling image; must support candidate executable ABI')
    args=parser.parse_args()
    inputs=args.inputs.resolve()
    provenance=json.loads((inputs/'provenance.json').read_text())
    head=call(['git','-C',str(TREE),'rev-parse','HEAD']).stdout.strip()
    assert head==provenance['head'], 'candidate source and current harness tree must match'
    assert provenance['clean'] is True
    assert not call(['git','-C',str(TREE),'diff','HEAD','--','src','crates']).stdout, 'runtime source must be clean'
    for name in ['rustbgpd','rbgp']:
        assert digest(inputs/name)==provenance['binaries'][name], name
    for name in NAMES.values():
        assert call(['docker','inspect',name],check=False).returncode!=0, f'pre-existing container {name}; refusing to touch it'
    base_image=call(['docker','image','inspect','--format','{{.Id}}',args.carrier_image]).stdout.strip()
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    original=TREE/'tests/interop'/f'{LAB}.clab.yml'
    topology=yaml.safe_load(original.read_text())
    (out/'topology-original.clab.yml').write_bytes(original.read_bytes())
    (out/'provenance.json').write_bytes((inputs/'provenance.json').read_bytes())
    (out/'run_m67.py').write_bytes(Path(__file__).read_bytes())
    owned_suffix=uuid.uuid4().hex[:8]
    tag=f'rustbgpd:m67-peer-sync-{head[:12]}-{owned_suffix}'
    network=f'm67-peer-sync-{owned_suffix}'
    for node in topology['topology']['nodes'].values():
        node['image']=tag
        binds=[]
        for binding in node.get('binds',[]):
            source,destination,mode=binding.rsplit(':',2)
            source_path=(original.parent/source).resolve()
            relative=source_path.relative_to(TREE)
            retained=out/'fixture'/relative
            retained.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(source_path,retained)
            binds.append(f'{retained}:{destination}:{mode}')
        binds.extend(f'{inputs/name}:/usr/local/bin/{name}:ro' for name in ['rustbgpd','rbgp'])
        node['binds']=binds
    watched=[TREE/'tests/interop/scripts'/name for name in ['test-m67-evpn-link-drain-failover.sh','test-lib.sh','source-id-guard.sh']]
    hashes={str(path.relative_to(TREE)):digest(path) for path in watched}
    for path in watched:
        shutil.copyfile(path,out/path.name)
    metadata=dict(daemon_source_commit=head, binaries=provenance['binaries'], carrier_image=base_image, owned_image_tag=tag,
                  owned_network=network, containers=NAMES, driver_sha256=hashes,
                  identity_guard='verified actual read-only mounted executable hashes in all five nodes; carrier image is not claimed as a candidate build',
                  changes_from_standard_topology=['image reference', 'absolute retained bind sources', 'read-only candidate executable binds', 'owned management network'],
                  M67_RERUN='0', kernel=call(['uname','-r']).stdout.strip())
    topology_path=out/f'{LAB}.clab.yml'
    stop=threading.Event()
    observer=None
    monitors=[]
    image_created=False
    network_created=False
    deployed=False
    cleanup=[]
    result_code=None
    owned_processes={}
    try:
        call(['docker','tag',base_image,tag])
        image_created=True
        call(['docker','network','create','--label','purpose=m67-peer-sync-proof',network])
        network_created=True
        net=json.loads(call(['docker','network','inspect',network]).stdout)[0]
        subnet=next(entry['Subnet'] for entry in net['IPAM']['Config'] if ':' not in entry['Subnet'])
        topology['mgmt']={'network':network,'ipv4-subnet':subnet}
        topology_path.write_text(yaml.safe_dump(topology,sort_keys=False))
        metadata['management_subnet']=subnet
        (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
        with (out/'deploy.log').open('w') as log:
            deployed=True
            deployment=subprocess.run(['containerlab','deploy','-t',str(topology_path)],cwd=out,stdout=log,stderr=log,timeout=180)
            (out/'deploy.exit').write_text(str(deployment.returncode)+'\n')
            deployment.check_returncode()
        identities={}
        for node,name in NAMES.items():
            values=call(['docker','exec',name,'sha256sum','/usr/local/bin/rustbgpd','/usr/local/bin/rbgp']).stdout
            identities[node]=values
            lines=values.splitlines()
            assert lines[0].split()[0]==provenance['binaries']['rustbgpd']
            assert lines[1].split()[0]==provenance['binaries']['rbgp']
            image_id=call(['docker','inspect','-f','{{.Image}}',name]).stdout.strip()
            assert image_id==base_image
        (out/'verified-runtime-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
        for name in NAMES.values():
            top=call(['docker','top',name,'-eo','pid,args']).stdout
            (out/(name+'-processes.txt')).write_text(top)
            for line in top.splitlines()[1:]:
                pid=line.split()[0]
                try:
                    owned_processes[pid]=Path('/proc',pid,'stat').read_text()
                except FileNotFoundError:
                    pass
        for node in ['vtep','pe1','pe2']:
            stream=(out/(node+'-fdb-monitor.log')).open('w')
            process=subprocess.Popen(['docker','exec',NAMES[node],'bridge','-t','monitor','fdb'],stdout=stream,stderr=stream)
            monitors.append((process,stream))
        observer=threading.Thread(target=observe,args=(out,stop),daemon=True)
        observer.start()
        env=os.environ.copy()
        env.update(M67_RERUN='0',CLEANUP='0')
        with (out/'driver.log').open('w') as log:
            execution=subprocess.run(['bash',str(watched[0])],cwd=TREE,env=env,stdout=log,stderr=log,timeout=1200)
            result_code=execution.returncode
            (out/'driver.exit').write_text(str(result_code)+'\n')
        assert all(digest(path)==hashes[str(path.relative_to(TREE))] for path in watched), 'harness changed while proof was running'
        summary=re.findall(r'Results: (\d+) passed, (\d+) failed',(out/'driver.log').read_text())
        result=dict(exit=result_code, summary=summary, candidate=head, binary_sha256=provenance['binaries']['rustbgpd'])
        (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2),flush=True)
    finally:
        stop.set()
        if observer is not None:
            observer.join(timeout=190)
            if observer.is_alive():
                cleanup.append(dict(kind='observer',error='did not stop before cleanup'))
        for process,stream in monitors:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
            stream.close()
        if deployed:
            for node in ['vtep','pe1','pe2']:
                result=observed(['docker','exec',NAMES[node],'cat','/var/log/rustbgpd.log'])
                (out/(node+'-daemon.log')).write_text(result.get('stdout',''))
            for phase in ['fail','recover']:
                result=observed(['docker','exec',NAMES['hr'],'cat',f'/tmp/m67-prober-{phase}.log'])
                (out/(phase+'-prober.log')).write_text(result.get('stdout',''))
            with (out/'destroy.log').open('w') as log:
                result=subprocess.run(['containerlab','destroy','-t',str(topology_path),'--cleanup'],cwd=out,stdout=log,stderr=log,timeout=180)
                cleanup.append(dict(kind='containerlab_destroy',exit=result.returncode))
            for name in NAMES.values():
                result=call(['docker','inspect',name],check=False)
                if result.returncode==0:
                    container=json.loads(result.stdout)[0]
                    if container['Config']['Image']==tag and container['Config']['Labels'].get('containerlab')==LAB:
                        removed=call(['docker','rm','-f',name],check=False)
                        cleanup.append(dict(kind='owned_container_fallback_remove',name=name,exit=removed.returncode,stderr=removed.stderr))
                        result=call(['docker','inspect',name],check=False)
                cleanup.append(dict(kind='container_absent',name=name,absent=result.returncode!=0,stderr=result.stderr))
        if network_created:
            existing=call(['docker','network','inspect',network],check=False)
            if existing.returncode==0:
                value=json.loads(existing.stdout)[0]
                assert not value['Containers'], 'owned management network still has containers'
                removed=call(['docker','network','rm',network],check=False)
                cleanup.append(dict(kind='network_remove',exit=removed.returncode,stderr=removed.stderr))
            absent=call(['docker','network','inspect',network],check=False)
            cleanup.append(dict(kind='network_absent',name=network,absent=absent.returncode!=0))
        if image_created:
            removed=call(['docker','image','rm',tag],check=False)
            cleanup.append(dict(kind='owned_tag_remove',exit=removed.returncode,stderr=removed.stderr))
        for pid,original in owned_processes.items():
            try:
                current=Path('/proc',pid,'stat').read_text()
                same=current.rsplit(')',1)[1].split()[19]==original.rsplit(')',1)[1].split()[19]
            except FileNotFoundError:
                same=False
            cleanup.append(dict(kind='owned_process_absent',pid=pid,absent=not same))
        ns=call(['ip','netns','list'],check=False)
        cleanup.append(dict(kind='owned_named_namespaces_absent',absent=LAB not in ns.stdout,stdout=ns.stdout,stderr=ns.stderr))
        (out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
        assert not any(row.get('absent') is False or row.get('exit',0)!=0 or 'error' in row for row in cleanup), 'cleanup incomplete'
    assert result_code==0, f'M67 unchanged driver failed; see {out}/driver.log'

if __name__=='__main__':
    main()
