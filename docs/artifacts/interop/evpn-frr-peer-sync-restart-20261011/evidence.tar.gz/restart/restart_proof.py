#!/usr/bin/env python3
"""Actual-daemon peer-row adoption and overlay conversion in an owned FRR lab."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
sys.path.insert(0, '/receipt')
import evpn_frr_peer_sync as p

ORPHAN = '02:aa:bb:cc:dd:fe'
BASELINE_SEEDS = [10,11,12,13,16,18,19,21,30,32,33,34,36,37,38,39,41,42,44,46,47,50,56,57,58,60,61,62,63,64,67,68,69,73]
EVENTS = p.OUT/'restart-events.jsonl'
SAMPLES = p.OUT/'restart-fdb-samples.jsonl'
original_popen = subprocess.Popen
daemon = None

def event(name, **fields):
    row = dict(event=name, monotonic=time.monotonic(), wall_time=time.time(), **fields)
    with EVENTS.open('a') as log:
        log.write(json.dumps(row)+'\n')
    return row

def retain_daemon(args, *a, **kw):
    global daemon
    proc = original_popen(args, *a, **kw)
    if '/binaries/rustbgpd' in args:
        daemon = proc
        event('daemon_started', pid=proc.pid, grace_seconds=int(os.environ['RUSTBGPD_EVPN_ADOPTION_REAP_DEFERRAL_SECS']))
    return proc

def rows():
    return json.loads(p.ns('b','bridge','-j','fdb','show'))

def peer_rows():
    selected = [row for row in rows() if row.get('mac')==p.MAC]
    p.verify_peer_rows(selected)
    return selected

def sample(phase):
    value = dict(phase=phase, monotonic=time.monotonic(), rows=rows())
    with SAMPLES.open('a') as log:
        log.write(json.dumps(value)+'\n')
    p.verify_peer_rows([row for row in value['rows'] if row.get('mac')==p.MAC])
    return value

def pair_ready():
    try:
        peer_rows()
        return True
    except AssertionError:
        return False

def remote_nhg_ready():
    fdb = json.loads(p.ns('r','bridge','-j','fdb','show','dev','vx100'))
    nhs = json.loads(p.ns('r','ip','-j','nexthop','show'))
    target = next((r for r in fdb if r.get('mac')==p.MAC and r.get('nhid')), None)
    if not target:
        return False
    group = next((r for r in nhs if r['id']==target['nhid']), {})
    ids = {r['id'] for r in group.get('group', [])}
    return len(ids)==2 and {r.get('via',r.get('gateway')) for r in nhs if r['id'] in ids}=={p.IPS['a'],p.IPS['b']}

def settled(name):
    p.wait(lambda: len(p.cli('b','neighbor'))==2 and all(r['state']=='Established' for r in p.cli('b','neighbor')), 'restarted EVPN sessions')
    p.wait(pair_ready, 'restarted exact peer FDB pair')
    p.wait(remote_nhg_ready, 'remote FRR exact two-member NHG after restart')
    p.wait(lambda: p.cli('b','evpn','es','list')['segments'][0]['members'][0]['df_role']=='nondf', 'B non-DF after restart')
    state=p.snapshot(name)
    seg=state['b']['segments']['segments'][0]
    assert seg['redundancy_mode']=='all-active' and not seg['drained']
    assert seg['members'][0]['df_role']=='nondf' and seg['members'][0]['same_esi_bias_eligible']
    assert any(r.get('ifname')=='es0' and r.get('flood') is False for r in state['b']['ports'])
    assert any(r.get('mac')==p.MAC and r.get('esi')==p.ESI for r in state['b']['routes'])
    assert not any(r.get('mac')==p.MAC and r.get('peer')=='0.0.0.0' for r in state['b']['routes'])
    peer_rows()
    return state

def kill(name):
    event(name+'_kill_requested', pid=daemon.pid, signal='SIGKILL')
    daemon.kill()
    code=daemon.wait(timeout=10)
    assert code==-signal.SIGKILL, code
    event(name+'_killed', pid=daemon.pid, exit=code)

def restart(name, grace):
    global daemon
    os.environ['RUSTBGPD_EVPN_ADOPTION_REAP_DEFERRAL_SECS']=str(grace)
    log=(p.OUT/(name+'-daemon.log')).open('w')
    started=event(name+'_restart_requested', grace_seconds=grace)
    daemon=retain_daemon([*p.prefix('b'),'/binaries/rustbgpd',str(p.OUT/'b.toml')], stdout=log, stderr=log)
    return started

def traffic(name):
    assert remote_nhg_ready()
    results=p.capture(name, BASELINE_SEEDS, 10)
    p.verify_delivery(results, name, BASELINE_SEEDS, 'b', True)
    settled(name+'-after')
    return dict(flows=34, frames_per_flow=10, decapsulated=340, CE_delivered=340, flow_seeds=BASELINE_SEEDS)

def main():
    os.environ['RUSTBGPD_EVPN_ADOPTION_REAP_DEFERRAL_SECS']='5'
    subprocess.Popen=retain_daemon
    try:
        p.main()
    finally:
        subprocess.Popen=original_popen
    initial=json.loads((p.OUT/'result.json').read_text())
    assert initial['flow_seeds']==BASELINE_SEEDS
    (p.OUT/'initial-result.json').write_text(json.dumps(initial,indent=2)+'\n')
    settled('peer-before-kill')
    monitor_log=(p.OUT/'peer-restart-fdb-monitor.log').open('w')
    monitor=original_popen([*p.prefix('b'),'bridge','-t','monitor','fdb'], stdout=monitor_log, stderr=monitor_log)
    kill('peer')
    sample('peer-stopped-before-restart')
    # This separate synthetic orphan is only a grace-expiry/reconcile control.
    # The target MAC's two rows were installed by the real daemon.
    p.ns('b','bridge','fdb','add',ORPHAN,'dev','vx100','master','extern_learn','dst','10.211.0.254')
    assert any(r.get('mac')==ORPHAN and 'extern_learn' in r.get('flags',[]) for r in rows())
    event('synthetic_orphan_seeded', mac=ORPHAN, dst='10.211.0.254')
    start=restart('peer',5)
    settled('peer-restarted')
    event('peer_intent_restored')
    deadline=time.monotonic()+80
    observed_reap=False
    while time.monotonic()<deadline:
        state=sample('peer-post-restart')
        log=(p.OUT/'peer-daemon.log').read_text()
        events = [json.loads(line).get('fields', {}) for line in log.splitlines() if line.startswith('{')]
        exact_reap = any(e.get('message')=='reaped adopted single-dst FDB row that no EVPN route re-claimed' and e.get('mac')==ORPHAN for e in events)
        if not any(r.get('mac')==ORPHAN for r in state['rows']) and exact_reap:
            observed_reap=True
            break
        time.sleep(.25)
    assert observed_reap, 'orphan control must prove grace expiry and actual reconcile'
    reap=event('peer_grace_expired_control_reaped', mac=ORPHAN, elapsed_seconds=time.monotonic()-start['monotonic'])
    assert reap['elapsed_seconds']>=5
    peer_delivery=traffic('peer-post-grace')
    monitor.terminate()
    monitor.wait(timeout=10)
    monitor_log.close()
    monitor_lines=(p.OUT/'peer-restart-fdb-monitor.log').read_text().splitlines()
    assert any('Deleted' in line and ORPHAN in line for line in monitor_lines), 'monitor must observe the control orphan deletion'
    target_deletions=[line for line in monitor_lines if 'Deleted' in line and p.MAC in line]
    assert not target_deletions, 'target peer rows were deleted during the restart/grace observation'
    event('peer_monitor_no_target_deletions')
    # A successful active drain creates the old overlay row through the daemon.
    p.cli('b','evpn','es','drain',p.ESI)
    p.wait(lambda: any(r.get('mac')==p.MAC and r.get('ifname')=='vx100' and r.get('dst')==p.IPS['a'] and 'extern_learn' in r.get('flags',[]) for r in rows()), 'real daemon-owned overlay after drain')
    overlay=p.snapshot('overlay-before-kill')
    assert overlay['b']['segments']['segments'][0]['drained']
    assert not any(r.get('mac')==p.MAC and r.get('ifname')=='es0' for r in overlay['b']['fdb'])
    event('drained_owned_overlay_ready')
    kill('overlay')
    stopped=rows()
    (p.OUT/'overlay-stopped-fdb.json').write_text(json.dumps(stopped,indent=2)+'\n')
    assert any(r.get('mac')==p.MAC and r.get('ifname')=='vx100' for r in stopped)
    start_overlay=restart('overlay',120)
    p.wait(pair_ready, 'overlay converted to exact peer pair')
    converted=event('overlay_converted_to_peer_pair', elapsed_seconds=time.monotonic()-start_overlay['monotonic'])
    assert converted['elapsed_seconds']<120, 'conversion must precede adoption grace expiry'
    sample('overlay-converted-before-grace')
    settled('overlay-restarted')
    overlay_delivery=traffic('overlay-post-restart')
    logs=(p.OUT/'overlay-daemon.log').read_text()
    assert 'RUSTBGPD_EVPN_ADOPTION_REAP_DEFERRAL_SECS overrides' in logs
    final=dict(initial_forwarding=initial, peer_restart=dict(grace_seconds=5, control_orphan_mac=ORPHAN, control_reap_elapsed_seconds=reap['elapsed_seconds'], forwarding=peer_delivery), overlay_restart=dict(grace_seconds=120, prior_overlay_installed_by='actual daemon after operator drain', restart_clears_in_memory_drain=True, conversion_elapsed_seconds=converted['elapsed_seconds'], forwarding=overlay_delivery))
    (p.OUT/'result.json').write_text(json.dumps(final,indent=2)+'\n')
    print(json.dumps(final,indent=2))

if __name__=='__main__':
    main()
