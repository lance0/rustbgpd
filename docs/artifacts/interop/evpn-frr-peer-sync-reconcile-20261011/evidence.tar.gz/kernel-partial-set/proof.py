import datetime
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

root = Path('<repo>')
artifacts = Path('<kernel-receipt>')
binary = root / 'target/debug/deps/netns_dataplane-3edc83adfc84269e'
name = 'evpn-peer-r2-netns-53b5cb1a'
image = 'ubuntu@sha256:da6fc2be547864451aa253836dd926da33623312df4a9a243e35dc877c378a78'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
assert head == '53b5cb1a1f2dfe7b56306b285211f013b1ae23f6', head
assert not status, status
body = '''set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends iproute2 iputils-ping procps
cat /etc/os-release
ldd --version
uname -a
ip -Version
bridge -Version
set +e
EVPN_LINUX_NETNS=1 /proof/netns_dataplane --exact --nocapture linux_dataplane_peer_sync_local_fdb_forwards_with_flood_off
proof_rc=$?
set -e
printf 'TEST_EXIT=%s\\n' "$proof_rc"
printf 'NETNS_AFTER_TEST\\n'
ip netns list
test -z "$(ip netns list)" || exit 91
exit "$proof_rc"
'''
command = ['docker', 'run', '--rm', '--name', name, '--cap-add=NET_ADMIN', '--cap-add=SYS_ADMIN', '--security-opt=apparmor=unconfined', '--mount', f'type=bind,source={binary},target=/proof/netns_dataplane,readonly', image, 'bash', '-c', body]
metadata = {'head': head, 'git_status': status, 'binary': str(binary), 'binary_sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(), 'image': image, 'selector': 'peer_sync_local_fdb', 'command': command, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(artifacts / 'peer-r2-netns-command.txt').write_text(shlex.join(command) + '\n')
(artifacts / 'peer-r2-netns-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
with (artifacts / 'peer-r2-netns-proof.log').open('w') as log:
    completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
metadata['exit_code'] = completed.returncode
metadata['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(artifacts / 'peer-r2-netns-proof.exit').write_text(str(completed.returncode) + '\n')
cleanup = subprocess.run(['docker', 'ps', '-a', '--filter', f'name=^/{name}$', '--format', '{{.ID}} {{.Names}} {{.Status}}'], text=True, capture_output=True)
metadata['cleanup'] = {'exit_code': cleanup.returncode, 'stdout': cleanup.stdout, 'stderr': cleanup.stderr}
(artifacts / 'peer-r2-netns-cleanup.json').write_text(json.dumps(metadata['cleanup'], indent=2) + '\n')
(artifacts / 'peer-r2-netns-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
assert cleanup.returncode == 0 and not cleanup.stdout.strip(), metadata['cleanup']
raise SystemExit(completed.returncode)
